package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Employee;
import com.example.demo.repository.EmployeeRepo;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepo employeeRepo;
	
	public void saveEmployee(Employee employee) {
		employeeRepo.save(employee);
	}
	
	public List<Employee> getAll(){
		List<Employee> employees=new ArrayList<>();
		employeeRepo.findAll().forEach(employees::add);
		return employees;
	}
}
